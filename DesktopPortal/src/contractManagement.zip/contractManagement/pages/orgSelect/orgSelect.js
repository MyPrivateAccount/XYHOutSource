import { connect } from 'react-redux';
import { closeOrgSelect, changeActiveOrg } from '../../actions/actionCreator';
import React, { Component } from 'react';
import { Button, Row, Col, Menu, Checkbox } from 'antd';

const { SubMenu } = Menu;
const itemStyle = {
    itemBorder: {
        position: 'relative',
        zIndex: '100',
        background: '#fff',
        width: '100%'
    },
    autoHeight: {
        height: '100%'
    }
}
function getTreeDeepth(orgTreeSource, curLevel){
    if(orgTreeSource.children){
        curLevel += 1;
        let tempLevel = curLevel;
        for(let i =0; i < orgTreeSource.children.length; i ++){
          let cnt = getTreeDeepth(orgTreeSource.children[i], tempLevel);
          if(cnt > tempLevel){
              tempLevel = cnt;
          }
        }
        curLevel = tempLevel;
    }
    return curLevel;
  }
class OrgSelect extends Component {
    state = {
        checkedOrgs: []
    }

    handleOrgChecked = (orgInfo, checked) => {
        // console.log("orgInfo checked:", orgInfo, checked);
        if (checked) {
            this.setState({ checkedOrgs: [orgInfo.id] });
            this.props.dispatch(changeActiveOrg(orgInfo));
        }
        this.props.dispatch(closeOrgSelect());
    }

    isDisableOrgCheck = (org) =>{
        let res = true;
        if(this.props.permissionOrgTree && this.props.permissionOrgTree.searchOrgList){
            let perOrg = this.props.permissionOrgTree.searchOrgList.find(item => item.id === org.id);
            if(perOrg !== undefined){
                res = false;
            }
        }
        return res;
       
    }
    getChildOrg(orgInfo) {
        if (orgInfo) {
            if (orgInfo.children.length === 0) {
                console.log('length===0:', orgInfo.organizationName);
                return (<Menu.Item key={orgInfo.id}>
                    <Checkbox onChange={(e) => this.handleOrgChecked(orgInfo, e.target.checked)} disabled={this.isDisableOrgCheck(orgInfo)} >{orgInfo.organizationName}</Checkbox>
                </Menu.Item>)
            } else {
                console.log('length !==0:', orgInfo.organizationName);
                return (<SubMenu key={orgInfo.id} title={<span><Checkbox onChange={(e) => this.handleOrgChecked(orgInfo, e.target.checked)} disabled={this.isDisableOrgCheck(orgInfo)}></Checkbox> {orgInfo.organizationName}</span>}>
                    {
                        orgInfo.children.map(org => this.getChildOrg(org))
                    }
                </SubMenu >)
            }
        }
    }

    render() {
        const searchOrgList = this.props.permissionOrgTree.searchOrgList;
        const searchOrgTree = this.props.permissionOrgTree.searchOrgTree;
        const levelsCount = this.props.permissionOrgTree.levelCount;
        const orgList = searchOrgTree;
        let level = this.props.orgInfo.levelCount;
        let span = Math.round(24 / levelsCount);
        //let levelTest = getTreeDeepth(this.props.orgInfo.orgList, 1);
        // console.log('this.props.orgInfo.orgList:', JSON.stringify(this.props.orgInfo.orgList));
        // console.log('levelTest:', this.props.orgInfo.levelCount)
        // const orgList = this.props.orgInfo.orgList;
        // const levelsCount = this.props.orgInfo.levelCount;
        //let span = Math.round(24 / levelsCount);
       console.log("部门选择:", JSON.stringify(orgList) ,levelsCount);
     
        return (
            <div style={itemStyle.itemBorder}>
                <Row style={itemStyle.autoHeight}>
                    <Col span={3} style={itemStyle.autoHeight}>
                        <Menu selectedKeys={this.state.checkedOrgs} style={itemStyle.autoHeight}>
                            <Menu.Item key="0"><Checkbox onChange={(e) => this.handleOrgChecked({ id: '0', organizationName: '不限' }, e.target.checked)}></Checkbox>不限</Menu.Item>
                            {orgList.map(org =>
                                this.getChildOrg(org)
                            )}
                        </Menu>
                    </Col>
                </Row>
            </div>
        )
    }

}

function mapStateToProps(state) {
    return {
        orgInfo: state.basicData.orgInfo,
        permissionOrgTree: state.basicData.permissionOrgTree,
    }
}

function mapDispatchToProps(dispatch) {
    return {
        dispatch
    };
}
export default connect(mapStateToProps, mapDispatchToProps)(OrgSelect);